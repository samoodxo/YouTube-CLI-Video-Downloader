#This program can be used to download youtube videos and audios
from pytubefix import YouTube
VIDEO_LOCATION = "Downloaded Videos"
AUDIO_LOCATION = "Downloaded Audios"



def main():
    print()
    print("Welcome to TubeDownloader!")
    print("-"*25)
    print("Input your selection:")
    print("1: Download Video")
    print("2: Download Audio")
    print("3: Exit")
    #initialise var
    inputSelection = 0
    not_downloaded = True
    while not_downloaded:
        inputSelection = int(input())
        if inputSelection == 1:
            Video_Link = input("Input Video Link: ")
            link = Video_Link
            try:
                print()
                #Initialize Object
                yt = YouTube(link)
                #now initialize other variables n stuff
                title = yt.title
                channel = yt.author
                views = yt.views
                DownloadVideo(yt,title,channel,views)
                not_downloaded = False
                # Get all streams and filter for mp4 files
            except:
                #If link is invalid, print except
                print("Error")
        elif inputSelection == 2:
            Video_Link = input("Input Video Link: ")
            link = Video_Link
            try:
                print()
                #Initialize Object
                yt = YouTube(link)
                #now initialize other variables n stuff
                title = yt.title
                channel = yt.author
                views = yt.views
                DownloadAudio(yt,title,channel,views)
                not_downloaded = False
                # Get all streams and filter for mp4 files
            except:
                #If link is invalid, print except
                print("Error")
            
        else:
            exit("Error: only input 1,2 or 3")


def DownloadVideo(yt,title,channel,views):

    mp4_streams_144p = yt.streams.filter(file_extension="mp4",type="video",res="144p",video_codec="av01.0.00M.08")
    mp4_streams_240p = yt.streams.filter(file_extension="mp4",type="video",res="240p",video_codec="av01.0.00M.08")
    mp4_streams_360p = yt.streams.filter(file_extension="mp4",type="video",res="360p",video_codec="av01.0.01M.08")
    mp4_streams_480p = yt.streams.filter(file_extension="mp4",type="video",res="480p",video_codec="av01.0.04M.08")
    mp4_streams_720p = yt.streams.filter(file_extension="mp4",type="video",res="720p",video_codec="av01.0.05M.08")
    mp4_streams_1080p = yt.streams.filter(file_extension="mp4",type="video",res="1080p",video_codec="av01.0.08M.08")

    available_videos = [mp4_streams_144p,mp4_streams_240p,mp4_streams_360p,mp4_streams_480p,mp4_streams_720p,mp4_streams_1080p]

    print(f"Channel: {channel} ")
    print(f"Video Title: {title}")
    print(f"Views: {views}")
    print("-"*25)

    #Loop through list to show user what resolution we have
    for streams in available_videos:
        for stream in streams:
            print(f"Resolution: {stream.resolution}, Associated Itag: {stream.itag}")

    #Ask user what resolution they want
    download_selection = input("Which Resolution would you like to download? (NO AUDIO.): ")

    #Loop again and make sure to download video.
    for streams in available_videos:
        for stream in streams:
            if download_selection.lower() == stream.resolution:
                stream.download(output_path=VIDEO_LOCATION)
                return print(f"{stream.title} successfully downloaded!")
    

def DownloadAudio(yt,title,channel,views):

    mp3_streams_128 = yt.streams.filter(type="audio",abr="128kbps")
    mp3_streams_160 = yt.streams.filter(type="audio",abr="160kbps")
   

    available_audios = [mp3_streams_128,mp3_streams_160]

    print(f"Channel: {channel} ")
    print(f"Video Title: {title}")
    print(f"Views: {views}")
    print("-"*25)

    #Loop through list to show user what audios we have
    for mp3s in available_audios:
        for mp3 in mp3s:
            print(mp3.abr)

    #Ask user what resolution they want?
    download_selection = input("Which Audio Would You Like To Download?: ")

    #loop again
    for mp3s in available_audios:
        for mp3 in mp3s:
            if download_selection.lower() == mp3.abr:
                mp3.download(output_path=AUDIO_LOCATION)
                return print("Audio Successfully Downloaded!")

main()



